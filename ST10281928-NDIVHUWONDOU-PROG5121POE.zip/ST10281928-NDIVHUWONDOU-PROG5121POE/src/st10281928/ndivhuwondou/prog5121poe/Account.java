/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10281928.ndivhuwondou.prog5121poe;

/**
 *
 * @author ndoum
 */
import java.util.Scanner;
import java.util.regex.Pattern;

public class Account {

    /**
     * @param args the command line arguments
     */
    static String name = "";
    static String lastName = "";
    static String userName = "";
    static String password = "";
    static String loginName = "";
    static String loginPassword = "";

    public static void main(String[] args) {
        // TODO code application logic here
        
        String status= null;
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your Name");
        name = input.nextLine();
        System.out.println("Please enter your Lastname");
        lastName = input.nextLine();
        System.out.println("Please enter your Username");
        userName = input.nextLine();
        while (!Login.checkUserName(userName)) {
            System.out.println(Login.registerUser());
            System.out.println("Please enter your Username");
            userName = input.nextLine();
        }
        System.out.println("Username successfully captured");
        System.out.println("Please enter your password");
        password = input.nextLine();
        while (!Login.checkPasswordComplexity(password)) {
            System.out.println(Login.registerUser());
            System.out.println("Please enter your Password");
            password = input.nextLine();
        }
        System.out.println("Password successfully captured");

        System.out.println(Login.registerUser());

        System.out.println("Please enter your user name for Login purposes");
        loginName = input.nextLine();
        System.out.println("Please enter your user password for Login purposes");
        loginPassword = input.nextLine();
        while (!Login.loginUser(loginName, userName, loginPassword, password)) {
            
            System.out.println(Login.returnLoginStatus(status, name,lastName));
            System.out.println("Please enter your user name for Login purposes");
            loginName = input.nextLine();
            System.out.println("Please enter your user password for Login purposes");
            loginPassword = input.nextLine();
        }
        
        System.out.println(Login.returnLoginStatus(status, name,lastName));
    }
   
       
    
}
